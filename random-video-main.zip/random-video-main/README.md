# Random Video

This repository is a reupload of the YellowGreg project.

## Note
As developers of YellowGreg, we have been granted permission to make this project public.

## License
This project is licensed under the MIT License.
(Meaning you can use it for free)

## Credits
Made by the YellowGreg.

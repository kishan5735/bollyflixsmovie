# Original 
- Made by YellowGreg you can find the original repository here: [Original](https://github.com/YellowGregs/BAD-API-Template)
